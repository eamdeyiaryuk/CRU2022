
#include "SimpleColor.h"

color::color()
{

}
color::~color()
{

}
void color::init(uint8_t s0, uint8_t s1, uint8_t s2, uint8_t s3, uint8_t sp)
{
  s0_pin = s0;
  s1_pin = s1;
  s2_pin = s2;
  s3_pin = s3;
  sp_pin = sp;

  pinMode(s0_pin, OUTPUT);
  pinMode(s1_pin, OUTPUT);
  pinMode(s2_pin, OUTPUT);
  pinMode(s3_pin, OUTPUT);
  pinMode(sp_pin, INPUT);

  digitalWrite(s0_pin, HIGH);
  digitalWrite(s1_pin, LOW); 
  // frequency 20% droping for arduino uno/mega 
}
void color::setTolerance(uint16_t t)
{
  tr = t;
}
void color::setCompareRed(uint16_t r_min, uint16_t r_max, uint16_t g_min, uint16_t g_max, uint16_t b_min, uint16_t b_max)
{
  cRed[0][0] = r_min;
  cRed[0][1] = g_min;
  cRed[0][2] = b_min;
  cRed[1][0] = r_max;
  cRed[1][1] = g_max;
  cRed[1][2] = b_max;
}
void color::setCompareYellow(uint16_t r_min, uint16_t r_max, uint16_t g_min, uint16_t g_max, uint16_t b_min, uint16_t b_max)
{
  cYel[0][0] = r_min;
  cYel[0][1] = g_min;
  cYel[0][2] = b_min;
  cYel[1][0] = r_max;
  cYel[1][1] = g_max;
  cYel[1][2] = b_max;
}
void color::setCompareBlue(uint16_t r_min, uint16_t r_max, uint16_t g_min, uint16_t g_max, uint16_t b_min, uint16_t b_max)
{
  cBlu[0][0] = r_min;
  cBlu[0][1] = g_min;
  cBlu[0][2] = b_min;
  cBlu[1][0] = r_max;
  cBlu[1][1] = g_max;
  cBlu[1][2] = b_max;  
}
void color::setCompareGreen(uint16_t r_min, uint16_t r_max, uint16_t g_min, uint16_t g_max, uint16_t b_min, uint16_t b_max)
{
  cGre[0][0] = r_min;
  cGre[0][1] = g_min;
  cGre[0][2] = b_min;
  cGre[1][0] = r_max;
  cGre[1][1] = g_max;
  cGre[1][2] = b_max;       
}
void color::readRawValue()
{
  for(int count=0; count<3; count++)
  {
    digitalWrite(s2_pin, s2_case[count]);
    digitalWrite(s3_pin, s3_case[count]);
    rawOut[count] = pulseIn(sp_pin, LOW); 
  }
}
void color::readRange()
{
  for(int count=0; count<3; count++)
  {
    digitalWrite(s2_pin, s2_case[count]);
    digitalWrite(s3_pin, s3_case[count]);
    rawOut[count] = pulseIn(sp_pin, LOW); 
    
    if(rawOut[count] > maxOut[count])
      maxOut[count] = rawOut[count];
    if(rawOut[count] < minOut[count])
      minOut[count] = rawOut[count]; 
      
    Serial.print(minOut[count]);  Serial.print("\t"); 
    Serial.print(maxOut[count]);  Serial.print("\t"); 
  }
  Serial.println();
}
char color::getColor()
{
  char cl = NULL;
  readRawValue();

  /* green condition */
       if(rawOut[0] >= cGre[0][0]-tr && rawOut[0] <= cGre[1][0]+tr
       && rawOut[1] >= cGre[0][1]-tr && rawOut[1] <= cGre[1][1]+tr
       && rawOut[2] >= cGre[0][2]-tr && rawOut[2] <= cGre[1][2]+tr)
          cl = 'G';
  /* red condition */
  else if(rawOut[0] >= cRed[0][0]-tr && rawOut[0] <= cRed[1][0]+tr
       && rawOut[1] >= cRed[0][1]-tr && rawOut[1] <= cRed[1][1]+tr
       && rawOut[2] >= cRed[0][2]-tr && rawOut[2] <= cRed[1][2]+tr)
          cl = 'R';
  /* yellow condition */
  else if(rawOut[0] >= cYel[0][0]-tr && rawOut[0] <= cYel[1][0]+tr
       && rawOut[1] >= cYel[0][1]-tr && rawOut[1] <= cYel[1][1]+tr
       && rawOut[2] >= cYel[0][2]-tr && rawOut[2] <= cYel[1][2]+tr)
          cl = 'Y';
  /* blue condition */
  else if(rawOut[0] >= cBlu[0][0]-tr && rawOut[0] <= cBlu[1][0]+tr
       && rawOut[1] >= cBlu[0][1]-tr && rawOut[1] <= cBlu[1][1]+tr
       && rawOut[2] >= cBlu[0][2]-tr && rawOut[2] <= cBlu[1][2]+tr)
          cl = 'B';  
  return cl;
}
    
    
