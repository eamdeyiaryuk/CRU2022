
#include <Arduino.h>    

class color
{
  private:  
    uint8_t s0_pin = -1;
    uint8_t s1_pin = -1;
    uint8_t s2_pin = -1;
    uint8_t s3_pin = -1;
    uint8_t sp_pin = -1;
    uint16_t tr = 0;  // Tolerance value
    boolean s2_case[3] = {0, 1, 0};
    boolean s3_case[3] = {0, 1, 1};
    uint16_t rawOut[3];
    uint16_t maxOut[3] = {0, 0, 0};
    uint16_t minOut[3] = {5000, 5000, 5000}; // index = r, g, b
    uint16_t cRed[2][3] = {};
    uint16_t cYel[2][3] = {};
    uint16_t cBlu[2][3] = {};
    uint16_t cGre[2][3] = {};
  public:
    color();  ~color();
    void init(uint8_t s0, uint8_t s1, uint8_t s2, uint8_t s3, uint8_t sp);
    void setTolerance(uint16_t t);
    void setCompareRed(uint16_t r_min, uint16_t r_max, uint16_t g_min, uint16_t g_max, uint16_t b_min, uint16_t b_max);
    void setCompareYellow(uint16_t r_min, uint16_t r_max, uint16_t g_min, uint16_t g_max, uint16_t b_min, uint16_t b_max);
    void setCompareBlue(uint16_t r_min, uint16_t r_max, uint16_t g_min, uint16_t g_max, uint16_t b_min, uint16_t b_max);
    void setCompareGreen(uint16_t r_min, uint16_t r_max, uint16_t g_min, uint16_t g_max, uint16_t b_min, uint16_t b_max);
    void readRawValue();
    void readRange();
    char getColor();
};
