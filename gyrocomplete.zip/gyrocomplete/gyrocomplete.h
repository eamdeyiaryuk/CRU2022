class gyro
{
	private:
	 
	  bool dmpReady = false; 

    uint8_t mpuIntStatus; 
    uint8_t devStatus; 
    uint8_t fifoBuffer[64];
    uint8_t teapotPacket[14] = { '$', 0x02, 0,0, 0,0, 0,0, 0,0, 0x00, 0x00, '\r', '\n' };
    int16_t packetSize; 
    uint16_t fifoCount; 
  
    float euler[3]; 
    float ypr[3]; 
    float yaw   = 0;
    float pitch = 0; 
    float row   = 0;
  
    float offsetXG, offsetYG, offsetZG, offsetZA;
    float val_step_1 ,val_step_2, setpoint;
  
  public:

    volatile bool mpuInterrupt = false; 
    
	  gyro();
		~gyro();

    void setOffset(int setXG, int setYG, int setZG, int setZA);
    void initializer();
    void prepare(long time_check);
    float getVal(bool fix);
    float getVal();
    void setpointReset();
    
};
