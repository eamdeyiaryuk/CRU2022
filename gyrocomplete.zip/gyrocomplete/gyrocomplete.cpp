#if defined(ARDUINO) && ARDUINO >= 100  // Arduino IDE Version
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
// standad arduino library 
#include "I2Cdev.h"
#include "MPU6050_6Axis_MotionApps20.h"
#if I2CDEV_IMPLEMENTATION == I2CDEV_ARDUINO_WIRE
 #include "Wire.h"
#endif

#define OUTPUT_READABLE_YAWPITCHROLL
#define LED 13

MPU6050 mpu;

Quaternion q; 
VectorInt16 aa; 
VectorInt16 aaReal; 
VectorInt16 aaWorld; 
VectorFloat gravity; 

#include "gyrocomplete.h"


gyro::gyro()
{
}
gyro::~gyro()
{
}

void gyro::setOffset(int setXG, int setYG, int setZG, int setZA)
{
 offsetXG = setXG;  
 offsetYG = setYG; 
 offsetZG = setZG;
 offsetZA = setZA;
}
void gyro::initializer()
{
  #if I2CDEV_IMPLEMENTATION == I2CDEV_ARDUINO_WIRE
  Wire.begin();
  TWBR = 24; 
 #elif I2CDEV_IMPLEMENTATION == I2CDEV_BUILTIN_FASTWIRE
  Fastwire::setup(400, true);
 #endif

 mpu.initialize();
 devStatus = mpu.dmpInitialize();

 mpu.setXGyroOffset(220);
 mpu.setYGyroOffset(76);
 mpu.setZGyroOffset(-85);
 mpu.setZAccelOffset(1788); 
 
 if (devStatus == 0) 
 {
  mpu.setDMPEnabled(true);
  mpuIntStatus = mpu.getIntStatus();
  dmpReady = true;
  packetSize = mpu.dmpGetFIFOPacketSize();
 }  
}
void gyro::prepare(long time_check)
{
 long timer = 0;
 while(1)
 {
  timer = millis();
  while((millis()-timer) < time_check){ getVal(); val_step_1 = yaw; }
  timer = millis();
  while((millis()-timer) < time_check){ getVal(); val_step_2 = yaw; }
 
  if(int(val_step_1) == int(val_step_2)){ break; }
 }
 getVal(); setpoint = yaw;
}
float gyro::getVal(bool fix)
{
 if (!dmpReady) return;
 while (!mpuInterrupt && fifoCount < packetSize){ }

 mpuInterrupt = false;
 mpuIntStatus = mpu.getIntStatus();

 fifoCount = mpu.getFIFOCount();

      if((mpuIntStatus & 0x10) || fifoCount == 1024){ mpu.resetFIFO(); } 
 else if (mpuIntStatus & 0x02) 
 {
  while (fifoCount < packetSize) fifoCount = mpu.getFIFOCount();
  mpu.getFIFOBytes(fifoBuffer, packetSize);
  fifoCount -= packetSize;
  #ifdef OUTPUT_READABLE_YAWPITCHROLL
  mpu.dmpGetQuaternion(&q, fifoBuffer);
  mpu.dmpGetGravity(&gravity, &q);
  mpu.dmpGetYawPitchRoll(ypr, &q, &gravity);

  yaw   = ypr[0] * (180/M_PI);
  pitch = ypr[1] * (180/M_PI); 
  row   = ypr[2] * (180/M_PI);
  #endif
 }
 if(yaw < 0) yaw = 360+yaw;
 
 // dead air fix
 if(fix == true)
 {
  if(setpoint >= 0 && setpoint <= 180)
  {
   if(yaw > setpoint+180) yaw = yaw-360;
  }
  else 
  {
   if(yaw < setpoint-180) yaw = 360+yaw;
  }
  yaw = setpoint-yaw;
 }
 return yaw;
}
float gyro::getVal()
{
 getVal(false);
}
void gyro::setpointReset()
{
  getVal(); setpoint = yaw;
}
